# Patch catalog release checklist

Complete this for every translation entry before publishing it.

## Legal and release material

- [ ] The patch contains no original ROM or BIOS.
- [ ] The patch may be redistributed under its release terms.
- [ ] Translator, hacker, tester, and tool credits are accurate.
- [ ] Artwork is original, licensed, or omitted.
- [ ] Release notes identify the required game region and revision.

## Source authentication

- [ ] Start from the exact owned ROM dump named by the release.
- [ ] Record its byte size.
- [ ] Record its lowercase SHA-256.
- [ ] Apply the final public IPS/BPS patch to a fresh copy.
- [ ] Confirm that the result is byte-identical to the emulator-tested release.
- [ ] Record the patched result's lowercase SHA-256.

## Runtime proof

- [ ] Boot the freshly patched output in the target emulator or hardware.
- [ ] Test beyond the title screen.
- [ ] Confirm representative menus, gameplay, save/load, and ending routes as applicable.
- [ ] Confirm checksum repair required by the target platform.
- [ ] Keep ROM-derived screenshots and artifacts private unless their publication is authorized.

## WordPress entry

- [ ] Translation title is clear.
- [ ] Original title is entered.
- [ ] System and exact ROM revision are entered.
- [ ] Translation version is entered.
- [ ] Credits and release URL are entered.
- [ ] The final `.ips` or `.bps` is attached.
- [ ] Patch format matches the attached file.
- [ ] Source size and source SHA-256 are entered.
- [ ] Target SHA-256 is entered.
- [ ] Download filename uses the correct ROM extension.
- [ ] Entry shows **Ready** in the ROM Patcher list.

## Browser proof

- [ ] Wrong-size input is rejected.
- [ ] Wrong-revision input is rejected by SHA-256.
- [ ] Correct input produces the expected filename.
- [ ] Download appears only after target SHA-256 verification.
- [ ] Downloaded output matches the recorded target SHA-256.
- [ ] The result boots in the target emulator or hardware.

