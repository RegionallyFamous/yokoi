=== Yokoi ROM Patcher ===
Contributors: regionallyfamous
Tags: blocks, rom patcher, translation, ips, bps
Requires at least: 6.4
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Apply verified IPS and BPS translation patches entirely in the visitor's browser. The ROM is never uploaded.

== Description ==

Yokoi ROM Patcher adds a dynamic Gutenberg block and a private translation-patch catalog. Visitors choose a game, select a ROM they legally dumped, and download a patched copy after exact source and output verification.

Features:

* Block-only front end; no shortcode.
* Browser-local IPS and BPS patching.
* Required source and target SHA-256 verification.
* BPS patch, source, and target CRC-32 verification.
* Admin-only IPS/BPS media uploads.
* Searchable game catalog with artwork, revision, version, and credits.
* No server-side ROM upload or processing.

The plugin contains no games, ROMs, BIOS files, translation patches, or copyrighted game artwork.

== Installation ==

1. Upload the plugin ZIP in Plugins > Add Plugin > Upload Plugin.
2. Activate Yokoi ROM Patcher.
3. Add and publish entries under ROM Patcher in the WordPress admin.
4. Insert the Yokoi ROM Patcher block into a page or template.

== Frequently Asked Questions ==

= Does the ROM get uploaded? =

No. The browser reads, hashes, patches, verifies, and downloads the ROM locally. WordPress serves only the page, public catalog metadata, and the translation patch.

= Which patch formats work? =

IPS and BPS. IPS run-length and truncate records are supported. All four BPS action modes and all BPS CRC-32 fields are supported.

= Why are two SHA-256 hashes required? =

The source hash prevents patching the wrong region or revision. The target hash ensures the exact verified translated release was produced before the download is offered.

= Why is my published patch missing from the block? =

It needs an attached IPS/BPS file, selected format, valid source SHA-256, and valid target SHA-256. The ROM Patcher list shows whether each entry is ready.

= Is there a shortcode? =

No. The patcher is intentionally available only as a Gutenberg block.

== Privacy ==

The visitor-selected ROM, its cryptographic hash, and the patched output stay in the browser and are not transmitted to WordPress by this plugin. The browser downloads the public patch file, so normal server or CDN logs may record that patch request.

== Changelog ==

= 0.1.0 =

* Initial block-only release.
* Add IPS and BPS browser patching.
* Add source and target SHA-256 release gates.
* Add private WordPress patch catalog.
