<?php
/**
 * WordPress admin catalog behavior.
 *
 * @package YokoiRomPatcher
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Patch catalog admin controller.
 */
final class YRP_Admin {
	/**
	 * Singleton instance.
	 *
	 * @var YRP_Admin|null
	 */
	private static $instance = null;

	/**
	 * Catalog field definitions.
	 *
	 * @var array
	 */
	private $fields = array(
		'_yrp_original_title'      => 'text',
		'_yrp_system'              => 'text',
		'_yrp_revision'            => 'text',
		'_yrp_patch_version'       => 'text',
		'_yrp_credits'             => 'text',
		'_yrp_credits_url'         => 'url',
		'_yrp_patch_format'        => 'format',
		'_yrp_patch_attachment_id' => 'integer',
		'_yrp_source_size'         => 'integer',
		'_yrp_source_sha256'       => 'hash',
		'_yrp_target_sha256'       => 'hash',
		'_yrp_output_filename'     => 'filename',
	);

	/**
	 * Retrieve the singleton.
	 *
	 * @return YRP_Admin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register admin-only hooks.
	 */
	public function boot() {
		add_action( 'add_meta_boxes_yrp_patch', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post_yrp_patch', array( $this, 'save_patch' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_filter( 'upload_mimes', array( $this, 'allow_patch_mimes' ), 10, 2 );
		add_filter( 'wp_check_filetype_and_ext', array( $this, 'check_patch_filetype' ), 10, 5 );
		add_filter( 'manage_yrp_patch_posts_columns', array( $this, 'add_columns' ) );
		add_action( 'manage_yrp_patch_posts_custom_column', array( $this, 'render_column' ), 10, 2 );
		add_action( 'admin_notices', array( $this, 'render_admin_notice' ) );
	}

	/**
	 * Register the translation patch post type.
	 */
	public static function register_post_type() {
		register_post_type(
			'yrp_patch',
			array(
				'labels'              => array(
					'name'               => __( 'ROM Patches', 'yokoi-rom-patcher' ),
					'singular_name'      => __( 'ROM Patch', 'yokoi-rom-patcher' ),
					'add_new_item'       => __( 'Add Translation Patch', 'yokoi-rom-patcher' ),
					'edit_item'          => __( 'Edit Translation Patch', 'yokoi-rom-patcher' ),
					'new_item'           => __( 'New Translation Patch', 'yokoi-rom-patcher' ),
					'view_item'          => __( 'View Translation Patch', 'yokoi-rom-patcher' ),
					'search_items'       => __( 'Search Translation Patches', 'yokoi-rom-patcher' ),
					'not_found'          => __( 'No translation patches found.', 'yokoi-rom-patcher' ),
					'menu_name'          => __( 'ROM Patcher', 'yokoi-rom-patcher' ),
					'featured_image'     => __( 'Game artwork', 'yokoi-rom-patcher' ),
					'set_featured_image' => __( 'Set game artwork', 'yokoi-rom-patcher' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_rest'        => true,
				'menu_icon'           => 'dashicons-download',
				'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
				'exclude_from_search' => true,
				'can_export'          => true,
				'rewrite'             => false,
			)
		);
	}

	/**
	 * Add the catalog details box.
	 */
	public function add_meta_boxes() {
		add_meta_box(
			'yrp-patch-details',
			__( 'Verified patch details', 'yokoi-rom-patcher' ),
			array( $this, 'render_meta_box' ),
			'yrp_patch',
			'normal',
			'high'
		);
	}

	/**
	 * Render the catalog details form.
	 *
	 * @param WP_Post $post Current post.
	 */
	public function render_meta_box( $post ) {
		wp_nonce_field( 'yrp_save_patch', 'yrp_patch_nonce' );
		$value = static function ( $key ) use ( $post ) {
			return (string) get_post_meta( $post->ID, $key, true );
		};
		$attachment_id   = absint( $value( '_yrp_patch_attachment_id' ) );
		$attachment_name = $attachment_id ? basename( (string) get_attached_file( $attachment_id ) ) : '';
		?>
		<p class="description"><?php esc_html_e( 'A published patch appears in the front-end catalog only when it has a patch file plus valid source and target SHA-256 hashes. Never upload a ROM here.', 'yokoi-rom-patcher' ); ?></p>
		<table class="form-table yrp-admin-fields" role="presentation">
			<tbody>
				<tr>
					<th><label for="yrp-original-title"><?php esc_html_e( 'Original title', 'yokoi-rom-patcher' ); ?></label></th>
					<td><input class="regular-text" id="yrp-original-title" name="_yrp_original_title" type="text" value="<?php echo esc_attr( $value( '_yrp_original_title' ) ); ?>"></td>
				</tr>
				<tr>
					<th><label for="yrp-system"><?php esc_html_e( 'System', 'yokoi-rom-patcher' ); ?></label></th>
					<td><input class="regular-text" id="yrp-system" name="_yrp_system" type="text" value="<?php echo esc_attr( $value( '_yrp_system' ) ); ?>" placeholder="<?php esc_attr_e( 'WonderSwan Color', 'yokoi-rom-patcher' ); ?>"></td>
				</tr>
				<tr>
					<th><label for="yrp-revision"><?php esc_html_e( 'Required ROM revision', 'yokoi-rom-patcher' ); ?></label></th>
					<td><input class="regular-text" id="yrp-revision" name="_yrp_revision" type="text" value="<?php echo esc_attr( $value( '_yrp_revision' ) ); ?>" placeholder="<?php esc_attr_e( 'Japan, Rev 1', 'yokoi-rom-patcher' ); ?>"></td>
				</tr>
				<tr>
					<th><label for="yrp-patch-version"><?php esc_html_e( 'Translation version', 'yokoi-rom-patcher' ); ?></label></th>
					<td><input class="regular-text" id="yrp-patch-version" name="_yrp_patch_version" type="text" value="<?php echo esc_attr( $value( '_yrp_patch_version' ) ); ?>" placeholder="1.0.0"></td>
				</tr>
				<tr>
					<th><label for="yrp-credits"><?php esc_html_e( 'Translator / team', 'yokoi-rom-patcher' ); ?></label></th>
					<td><input class="regular-text" id="yrp-credits" name="_yrp_credits" type="text" value="<?php echo esc_attr( $value( '_yrp_credits' ) ); ?>"></td>
				</tr>
				<tr>
					<th><label for="yrp-credits-url"><?php esc_html_e( 'Credits or release URL', 'yokoi-rom-patcher' ); ?></label></th>
					<td><input class="regular-text code" id="yrp-credits-url" name="_yrp_credits_url" type="url" value="<?php echo esc_attr( $value( '_yrp_credits_url' ) ); ?>"></td>
				</tr>
				<tr>
					<th><label for="yrp-patch-format"><?php esc_html_e( 'Patch format', 'yokoi-rom-patcher' ); ?></label></th>
					<td>
						<select id="yrp-patch-format" name="_yrp_patch_format">
							<option value="ips" <?php selected( $value( '_yrp_patch_format' ), 'ips' ); ?>>IPS</option>
							<option value="bps" <?php selected( $value( '_yrp_patch_format' ), 'bps' ); ?>>BPS</option>
						</select>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Patch file', 'yokoi-rom-patcher' ); ?></th>
					<td>
						<input class="yrp-patch-attachment-id" name="_yrp_patch_attachment_id" type="hidden" value="<?php echo esc_attr( $attachment_id ); ?>">
						<button class="button yrp-choose-patch" type="button"><?php esc_html_e( 'Choose IPS or BPS file', 'yokoi-rom-patcher' ); ?></button>
						<button class="button-link-delete yrp-remove-patch" type="button" <?php echo $attachment_id ? '' : 'hidden'; ?>><?php esc_html_e( 'Remove', 'yokoi-rom-patcher' ); ?></button>
						<span class="yrp-patch-filename"><?php echo esc_html( $attachment_name ); ?></span>
					</td>
				</tr>
				<tr>
					<th><label for="yrp-source-size"><?php esc_html_e( 'Expected ROM size (bytes)', 'yokoi-rom-patcher' ); ?></label></th>
					<td><input id="yrp-source-size" min="1" name="_yrp_source_size" type="number" value="<?php echo esc_attr( $value( '_yrp_source_size' ) ); ?>"> <span class="description"><?php esc_html_e( 'Optional fast check before hashing.', 'yokoi-rom-patcher' ); ?></span></td>
				</tr>
				<tr>
					<th><label for="yrp-source-sha256"><?php esc_html_e( 'Source ROM SHA-256', 'yokoi-rom-patcher' ); ?></label></th>
					<td><input class="large-text code" id="yrp-source-sha256" maxlength="64" name="_yrp_source_sha256" type="text" value="<?php echo esc_attr( $value( '_yrp_source_sha256' ) ); ?>" required></td>
				</tr>
				<tr>
					<th><label for="yrp-target-sha256"><?php esc_html_e( 'Patched ROM SHA-256', 'yokoi-rom-patcher' ); ?></label></th>
					<td><input class="large-text code" id="yrp-target-sha256" maxlength="64" name="_yrp_target_sha256" type="text" value="<?php echo esc_attr( $value( '_yrp_target_sha256' ) ); ?>" required></td>
				</tr>
				<tr>
					<th><label for="yrp-output-filename"><?php esc_html_e( 'Download filename', 'yokoi-rom-patcher' ); ?></label></th>
					<td><input class="regular-text code" id="yrp-output-filename" name="_yrp_output_filename" type="text" value="<?php echo esc_attr( $value( '_yrp_output_filename' ) ); ?>" placeholder="game-english.wsc"></td>
				</tr>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Save patch metadata.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post Current post.
	 */
	public function save_patch( $post_id, $post ) {
		if ( ! isset( $_POST['yrp_patch_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['yrp_patch_nonce'] ) ), 'yrp_save_patch' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( 'yrp_patch' !== $post->post_type || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( $this->fields as $key => $type ) {
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$raw   = wp_unslash( $_POST[ $key ] );
			$value = $this->sanitize_value( $raw, $type );

			if ( '' === $value || 0 === $value ) {
				delete_post_meta( $post_id, $key );
			} else {
				update_post_meta( $post_id, $key, $value );
			}
		}
	}

	/**
	 * Sanitize one catalog field.
	 *
	 * @param mixed  $raw Raw value.
	 * @param string $type Field type.
	 * @return string|int
	 */
	private function sanitize_value( $raw, $type ) {
		switch ( $type ) {
			case 'url':
				return esc_url_raw( $raw );
			case 'integer':
				return absint( $raw );
			case 'filename':
				return sanitize_file_name( $raw );
			case 'format':
				$value = strtolower( sanitize_key( $raw ) );
				return in_array( $value, array( 'ips', 'bps' ), true ) ? $value : '';
			case 'hash':
				return strtolower( trim( sanitize_text_field( $raw ) ) );
			case 'text':
			default:
				return sanitize_text_field( $raw );
		}
	}

	/**
	 * Load the media picker only on patch editing screens.
	 *
	 * @param string $hook_suffix Current admin hook.
	 */
	public function enqueue_admin_assets( $hook_suffix ) {
		$screen = get_current_screen();
		if ( ! $screen || 'yrp_patch' !== $screen->post_type || ! in_array( $hook_suffix, array( 'post.php', 'post-new.php', 'edit.php' ), true ) ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_script( 'yrp-admin', YRP_URL . 'assets/js/admin.js', array( 'jquery' ), YRP_VERSION, true );
		wp_enqueue_style( 'yrp-admin', YRP_URL . 'assets/css/admin.css', array(), YRP_VERSION );
	}

	/**
	 * Permit authenticated administrators to upload patch files.
	 *
	 * @param array       $mimes Allowed MIME map.
	 * @param int|WP_User $user User.
	 * @return array
	 */
	public function allow_patch_mimes( $mimes, $user = null ) {
		$user_id = $user instanceof WP_User ? $user->ID : absint( $user );
		if ( $user_id ? user_can( $user_id, 'manage_options' ) : current_user_can( 'manage_options' ) ) {
			$mimes['ips|bps'] = 'application/octet-stream';
		}

		return $mimes;
	}

	/**
	 * Give WordPress a deterministic type for extension-only binary patches.
	 *
	 * @param array  $data Filetype data.
	 * @param string $file Full file path.
	 * @param string $filename Original filename.
	 * @param array  $mimes Allowed MIME types.
	 * @param string $real_mime Detected MIME type.
	 * @return array
	 */
	public function check_patch_filetype( $data, $file, $filename, $mimes, $real_mime = '' ) {
		unset( $file, $mimes, $real_mime );
		if ( ! current_user_can( 'manage_options' ) ) {
			return $data;
		}

		$extension = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		if ( in_array( $extension, array( 'ips', 'bps' ), true ) ) {
			$data['ext']             = $extension;
			$data['type']            = 'application/octet-stream';
			$data['proper_filename'] = $filename;
		}

		return $data;
	}

	/**
	 * Add useful catalog columns.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public function add_columns( $columns ) {
		$columns['yrp_system']  = __( 'System', 'yokoi-rom-patcher' );
		$columns['yrp_version'] = __( 'Version', 'yokoi-rom-patcher' );
		$columns['yrp_status']  = __( 'Patcher status', 'yokoi-rom-patcher' );

		return $columns;
	}

	/**
	 * Render one custom catalog column.
	 *
	 * @param string $column Column key.
	 * @param int    $post_id Post ID.
	 */
	public function render_column( $column, $post_id ) {
		if ( 'yrp_system' === $column ) {
			echo esc_html( get_post_meta( $post_id, '_yrp_system', true ) );
		} elseif ( 'yrp_version' === $column ) {
			echo esc_html( get_post_meta( $post_id, '_yrp_patch_version', true ) );
		} elseif ( 'yrp_status' === $column ) {
			if ( $this->is_complete( $post_id ) ) {
				echo '<span class="yrp-admin-status yrp-admin-status--ready">' . esc_html__( 'Ready', 'yokoi-rom-patcher' ) . '</span>';
			} else {
				echo '<span class="yrp-admin-status yrp-admin-status--incomplete">' . esc_html__( 'Incomplete', 'yokoi-rom-patcher' ) . '</span>';
			}
		}
	}

	/**
	 * Warn when a published entry is excluded from the public catalog.
	 */
	public function render_admin_notice() {
		$screen = get_current_screen();
		if ( ! $screen || 'yrp_patch' !== $screen->post_type || 'post' !== $screen->base || empty( $_GET['post'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$post_id = absint( $_GET['post'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'publish' === get_post_status( $post_id ) && ! $this->is_complete( $post_id ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'This patch is published but hidden from the patcher because its patch file or SHA-256 hashes are incomplete.', 'yokoi-rom-patcher' ) . '</p></div>';
		}
	}

	/**
	 * Check whether an entry can safely appear in the front-end catalog.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private function is_complete( $post_id ) {
		$source_hash = strtolower( (string) get_post_meta( $post_id, '_yrp_source_sha256', true ) );
		$target_hash = strtolower( (string) get_post_meta( $post_id, '_yrp_target_sha256', true ) );
		$format      = strtolower( (string) get_post_meta( $post_id, '_yrp_patch_format', true ) );
		$attachment  = absint( get_post_meta( $post_id, '_yrp_patch_attachment_id', true ) );

		return (bool) (
			preg_match( '/^[a-f0-9]{64}$/', $source_hash )
			&& preg_match( '/^[a-f0-9]{64}$/', $target_hash )
			&& in_array( $format, array( 'ips', 'bps' ), true )
			&& $attachment
			&& wp_get_attachment_url( $attachment )
		);
	}
}

