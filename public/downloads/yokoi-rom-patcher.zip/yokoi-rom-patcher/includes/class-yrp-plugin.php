<?php
/**
 * Front-end and shared plugin behavior.
 *
 * @package YokoiRomPatcher
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin controller.
 */
final class YRP_Plugin {
	/**
	 * Singleton instance.
	 *
	 * @var YRP_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Number of patcher instances rendered on this request.
	 *
	 * @var int
	 */
	private $instance_count = 0;

	/**
	 * Retrieve the singleton.
	 *
	 * @return YRP_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register plugin hooks.
	 */
	public function boot() {
		add_action( 'init', array( 'YRP_Admin', 'register_post_type' ) );
		add_action( 'init', array( $this, 'register_block' ) );
		add_action( 'admin_init', array( $this, 'add_privacy_policy_content' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( YRP_FILE ), array( $this, 'add_action_links' ) );

		// Register capability-gated upload filters on REST requests as well as admin pages.
		YRP_Admin::instance()->boot();
	}

	/**
	 * Register the editor block.
	 */
	public function register_block() {
		register_block_type(
			YRP_DIR . 'blocks/rom-patcher',
			array(
				'render_callback' => array( $this, 'render_block' ),
			)
		);
	}

	/**
	 * Render the dynamic block.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public function render_block( $attributes ) {
		$title = isset( $attributes['title'] ) ? $attributes['title'] : '';

		return $this->render_patcher( $title );
	}

	/**
	 * Render the browser-local patcher for the dynamic block.
	 *
	 * @param string $title Block heading.
	 * @return string
	 */
	private function render_patcher( $title ) {
		$title   = $title ? sanitize_text_field( $title ) : __( 'Play it in English', 'yokoi-rom-patcher' );
		$catalog = $this->get_catalog();

		$this->enqueue_frontend_assets();

		++$this->instance_count;
		$instance_id = 'yrp-patcher-' . $this->instance_count;
		$config_id   = $instance_id . '-config';
		$config       = array(
			'patches'       => $catalog,
			'workerUrl'     => YRP_URL . 'assets/js/patch-worker.js',
			'maxRomBytes'   => (int) apply_filters( 'yrp_max_rom_bytes', 268435456 ),
			'maxPatchBytes' => (int) apply_filters( 'yrp_max_patch_bytes', 67108864 ),
			'strings'       => array(
				'choosePatch'       => __( 'Choose a translation first.', 'yokoi-rom-patcher' ),
				'chooseRom'         => __( 'Choose your ROM file.', 'yokoi-rom-patcher' ),
				'hashing'           => __( 'Checking your ROM…', 'yokoi-rom-patcher' ),
				'wrongRom'          => __( 'This is not the exact ROM revision this patch expects.', 'yokoi-rom-patcher' ),
				'downloadingPatch'  => __( 'Loading the translation patch…', 'yokoi-rom-patcher' ),
				'applyingPatch'     => __( 'Applying the translation…', 'yokoi-rom-patcher' ),
				'verifyingOutput'   => __( 'Verifying the finished game…', 'yokoi-rom-patcher' ),
				'ready'             => __( 'Your translated ROM is ready.', 'yokoi-rom-patcher' ),
				'genericError'      => __( 'The patch could not be applied.', 'yokoi-rom-patcher' ),
				'networkError'      => __( 'The patch file could not be downloaded. Please try again.', 'yokoi-rom-patcher' ),
				'insecureBrowser'   => __( 'ROM verification needs a modern browser on an HTTPS site.', 'yokoi-rom-patcher' ),
				'fileTooLarge'      => __( 'That file is larger than this patcher allows.', 'yokoi-rom-patcher' ),
				'patchTooLarge'     => __( 'The patch file is larger than this patcher allows.', 'yokoi-rom-patcher' ),
				'badOutput'         => __( 'The finished ROM did not match the verified release. Nothing was downloaded.', 'yokoi-rom-patcher' ),
				'ownershipRequired' => __( 'Confirm that you own the game before choosing a ROM.', 'yokoi-rom-patcher' ),
			),
		);

		ob_start();
		?>
		<section class="yrp" id="<?php echo esc_attr( $instance_id ); ?>" data-yrp-config="<?php echo esc_attr( $config_id ); ?>">
			<div class="yrp__header">
				<p class="yrp__eyebrow"><?php esc_html_e( 'Local browser patcher', 'yokoi-rom-patcher' ); ?></p>
				<h2 class="yrp__title"><?php echo esc_html( $title ); ?></h2>
				<p class="yrp__intro"><?php esc_html_e( 'Pick a translation, select your legally dumped ROM, and receive a verified patched copy. Your ROM never leaves this device.', 'yokoi-rom-patcher' ); ?></p>
			</div>

			<?php if ( empty( $catalog ) ) : ?>
				<div class="yrp__empty">
					<strong><?php esc_html_e( 'No translation patches are published yet.', 'yokoi-rom-patcher' ); ?></strong>
					<?php if ( current_user_can( 'edit_posts' ) ) : ?>
						<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=yrp_patch' ) ); ?>"><?php esc_html_e( 'Add the first patch', 'yokoi-rom-patcher' ); ?></a>
					<?php endif; ?>
				</div>
			<?php else : ?>
				<div class="yrp__layout">
					<div class="yrp__catalog" aria-labelledby="<?php echo esc_attr( $instance_id ); ?>-catalog-title">
						<div class="yrp__step-heading">
							<span>1</span>
							<h3 id="<?php echo esc_attr( $instance_id ); ?>-catalog-title"><?php esc_html_e( 'Choose a game', 'yokoi-rom-patcher' ); ?></h3>
						</div>
						<label class="yrp__search-label">
							<span class="screen-reader-text"><?php esc_html_e( 'Search translations', 'yokoi-rom-patcher' ); ?></span>
							<input class="yrp__search" type="search" placeholder="<?php esc_attr_e( 'Search games, systems, or translators…', 'yokoi-rom-patcher' ); ?>">
						</label>
						<div class="yrp__games" role="listbox" aria-label="<?php esc_attr_e( 'Translation patches', 'yokoi-rom-patcher' ); ?>"></div>
						<p class="yrp__no-results" hidden><?php esc_html_e( 'No translations match that search.', 'yokoi-rom-patcher' ); ?></p>
					</div>

					<div class="yrp__workspace">
						<div class="yrp__step-heading">
							<span>2</span>
							<h3><?php esc_html_e( 'Add your ROM', 'yokoi-rom-patcher' ); ?></h3>
						</div>
						<div class="yrp__selection" hidden></div>
						<label class="yrp__ownership">
							<input class="yrp__ownership-input" type="checkbox">
							<span><?php esc_html_e( 'I dumped this ROM from a game I own and may make a personal backup.', 'yokoi-rom-patcher' ); ?></span>
						</label>
						<label class="yrp__dropzone" tabindex="0">
							<input class="yrp__file" type="file" hidden>
							<span class="yrp__drop-icon" aria-hidden="true">↓</span>
							<strong><?php esc_html_e( 'Choose ROM file', 'yokoi-rom-patcher' ); ?></strong>
							<small><?php esc_html_e( 'or drop it here — it stays in your browser', 'yokoi-rom-patcher' ); ?></small>
						</label>
						<div class="yrp__status" role="status" aria-live="polite" hidden>
							<span class="yrp__status-light" aria-hidden="true"></span>
							<span class="yrp__status-text"></span>
						</div>
						<button class="yrp__download" type="button" hidden><?php esc_html_e( 'Download translated ROM', 'yokoi-rom-patcher' ); ?></button>
						<button class="yrp__reset" type="button" hidden><?php esc_html_e( 'Patch another copy', 'yokoi-rom-patcher' ); ?></button>
						<p class="yrp__privacy-note"><?php esc_html_e( 'Only the small translation patch is downloaded. The original and patched ROM are never sent to this website.', 'yokoi-rom-patcher' ); ?></p>
					</div>
				</div>
			<?php endif; ?>
			<noscript><p class="yrp__noscript"><?php esc_html_e( 'This patcher requires JavaScript.', 'yokoi-rom-patcher' ); ?></p></noscript>
		</section>
		<script type="application/json" id="<?php echo esc_attr( $config_id ); ?>"><?php echo wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
		<?php

		return (string) ob_get_clean();
	}

	/**
	 * Build the public, ROM-free patch catalog.
	 *
	 * @param array $systems Optional system filter.
	 * @return array
	 */
	private function get_catalog( $systems = array() ) {
		$posts   = get_posts(
			array(
				'post_type'      => 'yrp_patch',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => array(
					'menu_order' => 'ASC',
					'title'      => 'ASC',
				),
				'no_found_rows'  => true,
			)
		);
		$catalog = array();

		foreach ( $posts as $post ) {
			$system = trim( (string) get_post_meta( $post->ID, '_yrp_system', true ) );
			if ( $systems && ! in_array( $system, $systems, true ) ) {
				continue;
			}

			$source_hash = strtolower( trim( (string) get_post_meta( $post->ID, '_yrp_source_sha256', true ) ) );
			$target_hash = strtolower( trim( (string) get_post_meta( $post->ID, '_yrp_target_sha256', true ) ) );
			$format      = strtolower( trim( (string) get_post_meta( $post->ID, '_yrp_patch_format', true ) ) );
			$attachment  = absint( get_post_meta( $post->ID, '_yrp_patch_attachment_id', true ) );
			$patch_url   = $attachment ? wp_get_attachment_url( $attachment ) : '';

			if ( ! preg_match( '/^[a-f0-9]{64}$/', $source_hash ) || ! preg_match( '/^[a-f0-9]{64}$/', $target_hash ) || ! in_array( $format, array( 'ips', 'bps' ), true ) || ! $patch_url ) {
				continue;
			}

			$catalog[] = array(
				'id'             => (int) $post->ID,
				'title'          => get_the_title( $post ),
				'originalTitle'  => (string) get_post_meta( $post->ID, '_yrp_original_title', true ),
				'system'         => $system,
				'revision'       => (string) get_post_meta( $post->ID, '_yrp_revision', true ),
				'version'        => (string) get_post_meta( $post->ID, '_yrp_patch_version', true ),
				'credits'        => (string) get_post_meta( $post->ID, '_yrp_credits', true ),
				'creditsUrl'     => esc_url_raw( (string) get_post_meta( $post->ID, '_yrp_credits_url', true ) ),
				'description'    => wp_strip_all_tags( get_the_excerpt( $post ) ),
				'image'          => get_the_post_thumbnail_url( $post, 'medium' ) ?: '',
				'patchUrl'       => esc_url_raw( $patch_url ),
				'patchFormat'    => $format,
				'sourceSha256'   => $source_hash,
				'targetSha256'   => $target_hash,
				'sourceSize'     => absint( get_post_meta( $post->ID, '_yrp_source_size', true ) ),
				'outputFilename' => sanitize_file_name( (string) get_post_meta( $post->ID, '_yrp_output_filename', true ) ),
			);
		}

		return apply_filters( 'yrp_public_catalog', $catalog, $systems );
	}

	/**
	 * Register and enqueue front-end files only when the patcher renders.
	 */
	private function enqueue_frontend_assets() {
		wp_enqueue_style( 'yrp-frontend', YRP_URL . 'assets/css/frontend.css', array(), YRP_VERSION );
		wp_enqueue_script( 'yrp-patch-engines', YRP_URL . 'assets/js/patch-engines.js', array(), YRP_VERSION, true );
		wp_enqueue_script( 'yrp-frontend', YRP_URL . 'assets/js/frontend.js', array( 'yrp-patch-engines' ), YRP_VERSION, true );
	}

	/**
	 * Add plugin-row shortcuts.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function add_action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'edit.php?post_type=yrp_patch' ) ) . '">' . esc_html__( 'Patch catalog', 'yokoi-rom-patcher' ) . '</a>'
		);

		return $links;
	}

	/**
	 * Explain the plugin's browser-only file handling in the privacy guide.
	 */
	public function add_privacy_policy_content() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		wp_add_privacy_policy_content(
			__( 'Yokoi ROM Patcher', 'yokoi-rom-patcher' ),
			wp_kses_post(
				__( '<p>Yokoi ROM Patcher processes a visitor-selected ROM entirely in that visitor’s browser. The ROM, its cryptographic hash, and the patched output are not uploaded to or stored by WordPress. The browser downloads only the translation patch published by the site.</p>', 'yokoi-rom-patcher' )
			)
		);
	}
}
