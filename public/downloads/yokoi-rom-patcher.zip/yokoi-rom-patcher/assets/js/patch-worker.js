'use strict';

importScripts('patch-engines.js');

self.addEventListener('message', function (event) {
	try {
		var output = self.YokoiPatchEngines.applyPatch(
			new Uint8Array(event.data.source),
			new Uint8Array(event.data.patch),
			event.data.format,
			{maxOutputSize: event.data.maxOutputSize}
		);
		var transferable = output.buffer.slice(output.byteOffset, output.byteOffset + output.byteLength);
		self.postMessage({ok: true, output: transferable}, [transferable]);
	} catch (error) {
		self.postMessage({
			ok: false,
			code: error && error.code ? error.code : 'PATCH_FAILED',
			message: error && error.message ? error.message : 'The patch could not be applied.'
		});
	}
});

