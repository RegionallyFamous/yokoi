(function (root, factory) {
	'use strict';

	var api = factory();

	if (typeof module === 'object' && module.exports) {
		module.exports = api;
	}

	root.YokoiPatchEngines = api;
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
	'use strict';

	var DEFAULT_MAX_OUTPUT_SIZE = 1024 * 1024 * 1024;
	var CRC_TABLE = null;

	function PatchError(code, message) {
		this.name = 'PatchError';
		this.code = code;
		this.message = message;
		if (Error.captureStackTrace) {
			Error.captureStackTrace(this, PatchError);
		}
	}

	PatchError.prototype = Object.create(Error.prototype);
	PatchError.prototype.constructor = PatchError;

	function fail(code, message) {
		throw new PatchError(code, message);
	}

	function asBytes(value, label) {
		if (value instanceof Uint8Array) {
			return value;
		}
		if (value instanceof ArrayBuffer) {
			return new Uint8Array(value);
		}
		if (ArrayBuffer.isView(value)) {
			return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
		}

		fail('INVALID_BYTES', (label || 'Value') + ' must be an ArrayBuffer or typed array.');
	}

	function matchesAscii(bytes, offset, text) {
		if (offset + text.length > bytes.length) {
			return false;
		}

		for (var index = 0; index < text.length; index += 1) {
			if (bytes[offset + index] !== text.charCodeAt(index)) {
				return false;
			}
		}

		return true;
	}

	function maxOutputSize(options) {
		var configured = options && Number(options.maxOutputSize);

		if (Number.isSafeInteger(configured) && configured > 0) {
			return configured;
		}

		return DEFAULT_MAX_OUTPUT_SIZE;
	}

	function ensureCapacity(bytes, needed, maximum) {
		if (needed > maximum) {
			fail('OUTPUT_TOO_LARGE', 'The patch output exceeds the configured safety limit.');
		}
		if (needed <= bytes.length) {
			return bytes;
		}

		var nextLength = Math.max(bytes.length || 1, 1024);
		while (nextLength < needed) {
			nextLength = Math.min(maximum, nextLength * 2);
			if (nextLength < needed && nextLength === maximum) {
				fail('OUTPUT_TOO_LARGE', 'The patch output exceeds the configured safety limit.');
			}
		}

		var expanded = new Uint8Array(nextLength);
		expanded.set(bytes);
		return expanded;
	}

	function readU24BE(bytes, offset) {
		if (offset + 3 > bytes.length) {
			fail('TRUNCATED_PATCH', 'The patch ends in the middle of a 24-bit value.');
		}

		return (bytes[offset] * 0x10000) + (bytes[offset + 1] * 0x100) + bytes[offset + 2];
	}

	function readU16BE(bytes, offset) {
		if (offset + 2 > bytes.length) {
			fail('TRUNCATED_PATCH', 'The patch ends in the middle of a 16-bit value.');
		}

		return (bytes[offset] * 0x100) + bytes[offset + 1];
	}

	function applyIps(sourceValue, patchValue, options) {
		var source = asBytes(sourceValue, 'Source');
		var patch = asBytes(patchValue, 'Patch');
		var maximum = maxOutputSize(options);

		if (!matchesAscii(patch, 0, 'PATCH')) {
			fail('BAD_IPS_HEADER', 'This file does not have an IPS header.');
		}
		if (source.length > maximum) {
			fail('OUTPUT_TOO_LARGE', 'The source exceeds the configured safety limit.');
		}

		var output = new Uint8Array(source.length);
		output.set(source);
		var outputLength = source.length;
		var position = 5;
		var foundEnd = false;

		while (position < patch.length) {
			if (matchesAscii(patch, position, 'EOF')) {
				position += 3;
				foundEnd = true;
				break;
			}

			var offset = readU24BE(patch, position);
			position += 3;
			var length = readU16BE(patch, position);
			position += 2;

			if (length === 0) {
				var runLength = readU16BE(patch, position);
				position += 2;
				if (position >= patch.length) {
					fail('TRUNCATED_PATCH', 'The IPS run-length record is missing its byte.');
				}
				if (runLength === 0) {
					fail('BAD_IPS_RECORD', 'An IPS run-length record cannot be empty.');
				}

				output = ensureCapacity(output, offset + runLength, maximum);
				output.fill(patch[position], offset, offset + runLength);
				position += 1;
				outputLength = Math.max(outputLength, offset + runLength);
			} else {
				if (position + length > patch.length) {
					fail('TRUNCATED_PATCH', 'The IPS record is missing data bytes.');
				}

				output = ensureCapacity(output, offset + length, maximum);
				output.set(patch.subarray(position, position + length), offset);
				position += length;
				outputLength = Math.max(outputLength, offset + length);
			}
		}

		if (!foundEnd) {
			fail('MISSING_IPS_EOF', 'The IPS patch has no EOF marker.');
		}

		if (position < patch.length) {
			if (patch.length - position !== 3) {
				fail('BAD_IPS_TRAILER', 'The IPS patch has an invalid truncate extension.');
			}

			outputLength = readU24BE(patch, position);
			if (outputLength > maximum) {
				fail('OUTPUT_TOO_LARGE', 'The IPS truncate size exceeds the configured safety limit.');
			}
			output = ensureCapacity(output, outputLength, maximum);
		}

		return output.slice(0, outputLength);
	}

	function makeCrcTable() {
		var table = new Uint32Array(256);

		for (var index = 0; index < 256; index += 1) {
			var value = index;
			for (var bit = 0; bit < 8; bit += 1) {
				value = (value & 1) ? (0xedb88320 ^ (value >>> 1)) : (value >>> 1);
			}
			table[index] = value >>> 0;
		}

		return table;
	}

	function crc32(value, start, end) {
		var bytes = asBytes(value);
		var from = typeof start === 'number' ? start : 0;
		var to = typeof end === 'number' ? end : bytes.length;

		if (!CRC_TABLE) {
			CRC_TABLE = makeCrcTable();
		}

		var crc = 0xffffffff;
		for (var index = from; index < to; index += 1) {
			crc = CRC_TABLE[(crc ^ bytes[index]) & 0xff] ^ (crc >>> 8);
		}

		return (crc ^ 0xffffffff) >>> 0;
	}

	function readU32LE(bytes, offset) {
		if (offset + 4 > bytes.length) {
			fail('TRUNCATED_PATCH', 'The patch ends in the middle of a checksum.');
		}

		return (
			bytes[offset]
			+ (bytes[offset + 1] * 0x100)
			+ (bytes[offset + 2] * 0x10000)
			+ (bytes[offset + 3] * 0x1000000)
		) >>> 0;
	}

	function BpsReader(bytes, limit) {
		this.bytes = bytes;
		this.position = 4;
		this.limit = limit;
	}

	BpsReader.prototype.readNumber = function () {
		var data = 0;
		var shift = 1;

		while (true) {
			if (this.position >= this.limit) {
				fail('TRUNCATED_PATCH', 'The BPS patch ends in the middle of a variable-length number.');
			}

			var next = this.bytes[this.position];
			this.position += 1;
			data += (next & 0x7f) * shift;

			if (!Number.isSafeInteger(data)) {
				fail('BAD_BPS_NUMBER', 'A BPS number exceeds the safe integer range.');
			}
			if (next & 0x80) {
				return data;
			}

			shift *= 128;
			data += shift;
			if (!Number.isSafeInteger(shift) || !Number.isSafeInteger(data)) {
				fail('BAD_BPS_NUMBER', 'A BPS number exceeds the safe integer range.');
			}
		}
	};

	BpsReader.prototype.readSignedNumber = function () {
		var value = this.readNumber();
		var negative = value % 2 === 1;
		var magnitude = Math.floor(value / 2);

		return negative ? -magnitude : magnitude;
	};

	function applyBps(sourceValue, patchValue, options) {
		var source = asBytes(sourceValue, 'Source');
		var patch = asBytes(patchValue, 'Patch');
		var maximum = maxOutputSize(options);

		if (patch.length < 19 || !matchesAscii(patch, 0, 'BPS1')) {
			fail('BAD_BPS_HEADER', 'This file does not have a complete BPS header.');
		}

		var footerStart = patch.length - 12;
		var expectedSourceCrc = readU32LE(patch, footerStart);
		var expectedTargetCrc = readU32LE(patch, footerStart + 4);
		var expectedPatchCrc = readU32LE(patch, footerStart + 8);

		if (crc32(patch, 0, patch.length - 4) !== expectedPatchCrc) {
			fail('BAD_BPS_PATCH_CRC', 'The BPS patch checksum does not match.');
		}
		if (crc32(source) !== expectedSourceCrc) {
			fail('BAD_BPS_SOURCE_CRC', 'The source file does not match the BPS patch.');
		}

		var reader = new BpsReader(patch, footerStart);
		var sourceSize = reader.readNumber();
		var targetSize = reader.readNumber();
		var metadataSize = reader.readNumber();

		if (sourceSize !== source.length) {
			fail('BAD_BPS_SOURCE_SIZE', 'The source file size does not match the BPS patch.');
		}
		if (targetSize > maximum) {
			fail('OUTPUT_TOO_LARGE', 'The BPS output exceeds the configured safety limit.');
		}
		if (reader.position + metadataSize > footerStart) {
			fail('TRUNCATED_PATCH', 'The BPS metadata extends past the action stream.');
		}
		reader.position += metadataSize;

		var output = new Uint8Array(targetSize);
		var outputOffset = 0;
		var sourceRelativeOffset = 0;
		var targetRelativeOffset = 0;

		while (outputOffset < targetSize) {
			var action = reader.readNumber();
			var mode = action % 4;
			var length = Math.floor(action / 4) + 1;

			if (outputOffset + length > targetSize) {
				fail('BAD_BPS_ACTION', 'A BPS action writes past the target size.');
			}

			if (mode === 0) {
				if (outputOffset + length > source.length) {
					fail('BAD_BPS_SOURCE_READ', 'A BPS SourceRead action exceeds the source.');
				}
				output.set(source.subarray(outputOffset, outputOffset + length), outputOffset);
				outputOffset += length;
			} else if (mode === 1) {
				if (reader.position + length > footerStart) {
					fail('TRUNCATED_PATCH', 'A BPS TargetRead action is missing literal bytes.');
				}
				output.set(patch.subarray(reader.position, reader.position + length), outputOffset);
				reader.position += length;
				outputOffset += length;
			} else if (mode === 2) {
				sourceRelativeOffset += reader.readSignedNumber();
				if (sourceRelativeOffset < 0 || sourceRelativeOffset + length > source.length) {
					fail('BAD_BPS_SOURCE_COPY', 'A BPS SourceCopy action exceeds the source.');
				}
				for (var sourceIndex = 0; sourceIndex < length; sourceIndex += 1) {
					output[outputOffset] = source[sourceRelativeOffset];
					outputOffset += 1;
					sourceRelativeOffset += 1;
				}
			} else {
				targetRelativeOffset += reader.readSignedNumber();
				if (targetRelativeOffset < 0 || targetRelativeOffset >= outputOffset) {
					fail('BAD_BPS_TARGET_COPY', 'A BPS TargetCopy action points outside completed output.');
				}
				for (var targetIndex = 0; targetIndex < length; targetIndex += 1) {
					if (targetRelativeOffset >= outputOffset) {
						fail('BAD_BPS_TARGET_COPY', 'A BPS TargetCopy action reads unwritten output.');
					}
					output[outputOffset] = output[targetRelativeOffset];
					outputOffset += 1;
					targetRelativeOffset += 1;
				}
			}
		}

		if (reader.position !== footerStart) {
			fail('BAD_BPS_ACTION_STREAM', 'The BPS action stream has trailing or missing bytes.');
		}
		if (crc32(output) !== expectedTargetCrc) {
			fail('BAD_BPS_TARGET_CRC', 'The BPS target checksum does not match.');
		}

		return output;
	}

	function applyPatch(source, patch, format, options) {
		var normalized = String(format || '').toLowerCase();

		if (normalized === 'ips') {
			return applyIps(source, patch, options);
		}
		if (normalized === 'bps') {
			return applyBps(source, patch, options);
		}

		fail('UNSUPPORTED_FORMAT', 'Only IPS and BPS patches are supported.');
	}

	return {
		PatchError: PatchError,
		applyPatch: applyPatch,
		applyIps: applyIps,
		applyBps: applyBps,
		crc32: crc32
	};
}));
