(function () {
	'use strict';

	function qs(root, selector) {
		return root.querySelector(selector);
	}

	function formatBytes(bytes) {
		if (!bytes) {
			return '';
		}
		if (bytes < 1024) {
			return bytes + ' B';
		}
		if (bytes < 1024 * 1024) {
			return (bytes / 1024).toFixed(1) + ' KB';
		}

		return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
	}

	function hex(buffer) {
		return Array.prototype.map.call(new Uint8Array(buffer), function (byte) {
			return byte.toString(16).padStart(2, '0');
		}).join('');
	}

	function sha256(bytes) {
		if (!window.crypto || !window.crypto.subtle) {
			return Promise.reject(new Error('WEB_CRYPTO_UNAVAILABLE'));
		}

		return window.crypto.subtle.digest('SHA-256', bytes).then(hex);
	}

	function applyInWorker(sourceBuffer, patchBuffer, format, workerUrl, maxOutputSize) {
		if (!window.Worker) {
			return Promise.resolve(window.YokoiPatchEngines.applyPatch(
				new Uint8Array(sourceBuffer),
				new Uint8Array(patchBuffer),
				format,
				{maxOutputSize: maxOutputSize}
			));
		}

		return new Promise(function (resolve, reject) {
			var worker;
			try {
				worker = new Worker(workerUrl);
			} catch (error) {
				resolve(window.YokoiPatchEngines.applyPatch(
					new Uint8Array(sourceBuffer),
					new Uint8Array(patchBuffer),
					format,
					{maxOutputSize: maxOutputSize}
				));
				return;
			}

			worker.onmessage = function (event) {
				worker.terminate();
				if (event.data && event.data.ok) {
					resolve(new Uint8Array(event.data.output));
				} else {
					var patchError = new Error(event.data && event.data.message ? event.data.message : 'PATCH_FAILED');
					patchError.code = event.data && event.data.code ? event.data.code : 'PATCH_FAILED';
					reject(patchError);
				}
			};
			worker.onerror = function () {
				worker.terminate();
				reject(new Error('PATCH_WORKER_FAILED'));
			};
			worker.postMessage(
				{source: sourceBuffer, patch: patchBuffer, format: format, maxOutputSize: maxOutputSize},
				[sourceBuffer, patchBuffer]
			);
		});
	}

	function textNode(tag, className, value) {
		var node = document.createElement(tag);
		if (className) {
			node.className = className;
		}
		node.textContent = value || '';
		return node;
	}

	function fallbackFilename(file, patch) {
		if (patch.outputFilename) {
			return patch.outputFilename;
		}

		var dot = file.name.lastIndexOf('.');
		var stem = dot > 0 ? file.name.slice(0, dot) : file.name;
		var extension = dot > 0 ? file.name.slice(dot) : '.rom';
		return stem + '-english' + extension;
	}

	function init(root) {
		if (root.dataset.yrpReady === 'true') {
			return;
		}

		var configNode = document.getElementById(root.dataset.yrpConfig);
		if (!configNode) {
			return;
		}

		var config;
		try {
			config = JSON.parse(configNode.textContent);
		} catch (error) {
			return;
		}

		if (!config.patches || !config.patches.length) {
			root.dataset.yrpReady = 'true';
			return;
		}

		var games = qs(root, '.yrp__games');
		var search = qs(root, '.yrp__search');
		var noResults = qs(root, '.yrp__no-results');
		var selection = qs(root, '.yrp__selection');
		var ownership = qs(root, '.yrp__ownership-input');
		var dropzone = qs(root, '.yrp__dropzone');
		var fileInput = qs(root, '.yrp__file');
		var status = qs(root, '.yrp__status');
		var statusText = qs(root, '.yrp__status-text');
		var download = qs(root, '.yrp__download');
		var reset = qs(root, '.yrp__reset');
		var selectedPatch = null;
		var resultUrl = '';
		var resultFilename = '';
		var operation = 0;
		var cards = [];

		function setStatus(kind, message) {
			status.hidden = false;
			status.className = 'yrp__status yrp__status--' + kind;
			statusText.textContent = message;
		}

		function clearResult() {
			if (resultUrl) {
				URL.revokeObjectURL(resultUrl);
			}
			resultUrl = '';
			resultFilename = '';
			download.hidden = true;
			reset.hidden = true;
		}

		function resetWorkspace(keepStatus) {
			operation += 1;
			fileInput.value = '';
			clearResult();
			dropzone.classList.remove('yrp__dropzone--busy', 'yrp__dropzone--dragging');
			if (!keepStatus) {
				status.hidden = true;
			}
		}

		function showSelection(patch) {
			selection.replaceChildren();
			selection.appendChild(textNode('strong', '', patch.title));
			var details = [patch.system, patch.revision, patch.version ? 'Patch ' + patch.version : ''].filter(Boolean).join(' · ');
			selection.appendChild(textNode('span', '', details));
			selection.hidden = false;
		}

		function choosePatch(patch, card) {
			selectedPatch = patch;
			cards.forEach(function (item) {
				var active = item.card === card;
				item.card.classList.toggle('yrp__game--selected', active);
				item.card.setAttribute('aria-selected', active ? 'true' : 'false');
			});
			resetWorkspace(false);
			showSelection(patch);
		}

		config.patches.forEach(function (patch, index) {
			var card = document.createElement('button');
			card.type = 'button';
			card.className = 'yrp__game';
			card.setAttribute('role', 'option');
			card.setAttribute('aria-selected', 'false');
			card.dataset.search = [patch.title, patch.originalTitle, patch.system, patch.revision, patch.credits].join(' ').toLowerCase();

			var art = document.createElement('span');
			art.className = 'yrp__game-art';
			if (patch.image) {
				var image = document.createElement('img');
				image.src = patch.image;
				image.alt = '';
				image.loading = 'lazy';
				art.appendChild(image);
			} else {
				art.textContent = String(index + 1).padStart(2, '0');
			}

			var copy = document.createElement('span');
			copy.className = 'yrp__game-copy';
			copy.appendChild(textNode('strong', '', patch.title));
			copy.appendChild(textNode('span', '', [patch.system, patch.revision].filter(Boolean).join(' · ')));
			if (patch.credits) {
				copy.appendChild(textNode('small', '', 'Translation by ' + patch.credits));
			}

			var format = textNode('span', 'yrp__game-format', String(patch.patchFormat).toUpperCase());
			card.appendChild(art);
			card.appendChild(copy);
			card.appendChild(format);
			card.addEventListener('click', function () {
				choosePatch(patch, card);
			});
			games.appendChild(card);
			cards.push({card: card, patch: patch});
		});

		function filterCards() {
			var needle = search.value.trim().toLowerCase();
			var visible = 0;
			cards.forEach(function (item) {
				var match = !needle || item.card.dataset.search.indexOf(needle) !== -1;
				item.card.hidden = !match;
				visible += match ? 1 : 0;
			});
			noResults.hidden = visible !== 0;
		}

		search.addEventListener('input', filterCards);

		function handleError(error, token) {
			if (token !== operation) {
				return;
			}
			dropzone.classList.remove('yrp__dropzone--busy');
			var message = config.strings.genericError;
			if (error && error.message === 'WEB_CRYPTO_UNAVAILABLE') {
				message = config.strings.insecureBrowser;
			} else if (error && error.message === 'NETWORK_ERROR') {
				message = config.strings.networkError;
			} else if (error && error.message === 'PATCH_TOO_LARGE') {
				message = config.strings.patchTooLarge;
			} else if (error && error.message === 'BAD_OUTPUT') {
				message = config.strings.badOutput;
			}
			setStatus('error', message);
		}

		async function processFile(file) {
			clearResult();
			if (!selectedPatch) {
				setStatus('error', config.strings.choosePatch);
				return;
			}
			if (!ownership.checked) {
				setStatus('error', config.strings.ownershipRequired);
				fileInput.value = '';
				return;
			}
			if (!file) {
				setStatus('error', config.strings.chooseRom);
				return;
			}
			if (file.size > config.maxRomBytes) {
				setStatus('error', config.strings.fileTooLarge + ' ' + formatBytes(config.maxRomBytes) + ' maximum.');
				return;
			}
			if (selectedPatch.sourceSize && file.size !== selectedPatch.sourceSize) {
				setStatus('error', config.strings.wrongRom + ' Expected ' + formatBytes(selectedPatch.sourceSize) + '.');
				return;
			}

			var token = ++operation;
			dropzone.classList.add('yrp__dropzone--busy');

			try {
				setStatus('working', config.strings.hashing);
				var sourceBuffer = await file.arrayBuffer();
				var sourceHash = await sha256(sourceBuffer);
				if (token !== operation) {
					return;
				}
				if (sourceHash !== selectedPatch.sourceSha256) {
					dropzone.classList.remove('yrp__dropzone--busy');
					setStatus('error', config.strings.wrongRom);
					return;
				}

				setStatus('working', config.strings.downloadingPatch);
				var response;
				try {
					response = await fetch(selectedPatch.patchUrl, {credentials: 'same-origin', cache: 'force-cache'});
				} catch (networkError) {
					throw new Error('NETWORK_ERROR');
				}
				if (!response.ok) {
					throw new Error('NETWORK_ERROR');
				}
				var declaredSize = Number(response.headers.get('content-length'));
				if (declaredSize && declaredSize > config.maxPatchBytes) {
					throw new Error('PATCH_TOO_LARGE');
				}
				var patchBuffer = await response.arrayBuffer();
				if (patchBuffer.byteLength > config.maxPatchBytes) {
					throw new Error('PATCH_TOO_LARGE');
				}
				if (token !== operation) {
					return;
				}

				setStatus('working', config.strings.applyingPatch);
				await new Promise(function (resolve) { window.setTimeout(resolve, 20); });
				var output = await applyInWorker(
					sourceBuffer,
					patchBuffer,
					selectedPatch.patchFormat,
					config.workerUrl,
					config.maxRomBytes
				);

				setStatus('working', config.strings.verifyingOutput);
				var targetHash = await sha256(output);
				if (token !== operation) {
					return;
				}
				if (targetHash !== selectedPatch.targetSha256) {
					throw new Error('BAD_OUTPUT');
				}

				resultUrl = URL.createObjectURL(new Blob([output], {type: 'application/octet-stream'}));
				resultFilename = fallbackFilename(file, selectedPatch);
				dropzone.classList.remove('yrp__dropzone--busy');
				setStatus('success', config.strings.ready);
				download.hidden = false;
				reset.hidden = false;
				download.focus();
			} catch (error) {
				handleError(error, token);
			}
		}

		fileInput.addEventListener('change', function () {
			processFile(fileInput.files[0]);
		});

		['dragenter', 'dragover'].forEach(function (eventName) {
			dropzone.addEventListener(eventName, function (event) {
				event.preventDefault();
				dropzone.classList.add('yrp__dropzone--dragging');
			});
		});

		['dragleave', 'drop'].forEach(function (eventName) {
			dropzone.addEventListener(eventName, function (event) {
				event.preventDefault();
				dropzone.classList.remove('yrp__dropzone--dragging');
			});
		});

		dropzone.addEventListener('drop', function (event) {
			if (event.dataTransfer.files.length) {
				processFile(event.dataTransfer.files[0]);
			}
		});

		dropzone.addEventListener('keydown', function (event) {
			if (event.key === 'Enter' || event.key === ' ') {
				event.preventDefault();
				fileInput.click();
			}
		});

		download.addEventListener('click', function () {
			if (!resultUrl) {
				return;
			}
			var link = document.createElement('a');
			link.href = resultUrl;
			link.download = resultFilename;
			document.body.appendChild(link);
			link.click();
			link.remove();
		});

		reset.addEventListener('click', function () {
			resetWorkspace(false);
			fileInput.focus();
		});

		window.addEventListener('pagehide', clearResult, {once: true});
		root.dataset.yrpReady = 'true';
	}

	function initAll() {
		document.querySelectorAll('.yrp[data-yrp-config]').forEach(init);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initAll);
	} else {
		initAll();
	}
}());
