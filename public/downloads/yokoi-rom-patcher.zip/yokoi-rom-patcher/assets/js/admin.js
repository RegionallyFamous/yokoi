(function ($) {
	'use strict';

	$(function () {
		var frame;
		var idInput = $('.yrp-patch-attachment-id');
		var filename = $('.yrp-patch-filename');
		var remove = $('.yrp-remove-patch');

		$('.yrp-choose-patch').on('click', function (event) {
			event.preventDefault();
			if (frame) {
				frame.open();
				return;
			}

			frame = wp.media({
				title: 'Choose an IPS or BPS patch',
				button: {text: 'Use this patch'},
				multiple: false
			});

			frame.on('select', function () {
				var attachment = frame.state().get('selection').first().toJSON();
				var name = attachment.filename || '';
				var extension = name.split('.').pop().toLowerCase();
				if (extension !== 'ips' && extension !== 'bps') {
					window.alert('Please choose an .ips or .bps patch file.');
					return;
				}

				idInput.val(attachment.id);
				filename.text(name);
				$('#yrp-patch-format').val(extension);
				remove.prop('hidden', false);
			});

			frame.open();
		});

		remove.on('click', function (event) {
			event.preventDefault();
			idInput.val('');
			filename.text('');
			remove.prop('hidden', true);
		});
	});
}(jQuery));

