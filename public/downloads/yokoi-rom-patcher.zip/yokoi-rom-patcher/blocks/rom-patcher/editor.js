(function (blocks, element, components, blockEditor, i18n) {
	'use strict';

	var el = element.createElement;
	var InspectorControls = blockEditor.InspectorControls;
	var PanelBody = components.PanelBody;
	var TextControl = components.TextControl;

	blocks.registerBlockType('yokoi/rom-patcher', {
		edit: function (props) {
			return el(
				element.Fragment,
				{},
				el(
					InspectorControls,
					{},
					el(
						PanelBody,
						{title: i18n.__('Patcher settings', 'yokoi-rom-patcher')},
						el(TextControl, {
							label: i18n.__('Heading', 'yokoi-rom-patcher'),
							value: props.attributes.title,
							onChange: function (title) { props.setAttributes({title: title}); }
						})
					)
				),
				el(
					'div',
					{className: 'yrp-editor-preview'},
					el('span', {className: 'dashicons dashicons-download'}),
					el('strong', {}, props.attributes.title || i18n.__('Play it in English', 'yokoi-rom-patcher')),
					el('p', {}, i18n.__('The published translation catalog and browser patcher will appear here.', 'yokoi-rom-patcher'))
				)
			);
		},
		save: function () {
			return null;
		}
	});
}(window.wp.blocks, window.wp.element, window.wp.components, window.wp.blockEditor, window.wp.i18n));

