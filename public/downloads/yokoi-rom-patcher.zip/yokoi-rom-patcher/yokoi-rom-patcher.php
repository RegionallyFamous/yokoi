<?php
/**
 * Plugin Name:       Yokoi ROM Patcher
 * Plugin URI:        https://github.com/regionallyfamous/yokoi-rom-patcher
 * Description:       A privacy-first, browser-based ROM translation patcher for IPS and BPS patches.
 * Version:           0.1.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Regionally Famous
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       yokoi-rom-patcher
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'YRP_VERSION', '0.1.0' );
define( 'YRP_FILE', __FILE__ );
define( 'YRP_DIR', plugin_dir_path( __FILE__ ) );
define( 'YRP_URL', plugin_dir_url( __FILE__ ) );

require_once YRP_DIR . 'includes/class-yrp-plugin.php';
require_once YRP_DIR . 'includes/class-yrp-admin.php';

/**
 * Register the plugin's content type before refreshing rewrite rules.
 */
function yrp_activate() {
	YRP_Admin::register_post_type();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'yrp_activate' );

/**
 * Refresh rewrite rules on deactivation without deleting catalog data.
 */
function yrp_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'yrp_deactivate' );

YRP_Plugin::instance()->boot();

