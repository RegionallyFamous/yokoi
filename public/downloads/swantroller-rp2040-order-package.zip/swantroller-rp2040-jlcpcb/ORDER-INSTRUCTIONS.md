# Swantroller RP2040 — JLCPCB order notes

This package was reconstructed from the published Gerbers because the project does not include source PCB files, a BOM export, or a placement export. The assembly data covers the complete published RP2040 BOM: six resistors, three MOSFETs, and one Waveshare RP2040-Zero module.

## Upload these files

1. Upload `gerbers-jlcpcb.zip` as the PCB fabrication file.
2. Enable PCB assembly and select assembly on both sides.
3. Upload `bom-jlcpcb.csv` as the BOM.
4. Upload `cpl-jlcpcb.csv` as the CPL / pick-and-place file.

Do not upload the outer `swantroller-rp2040-jlcpcb-order.zip` to the PCB field. It is only a convenient archive of this whole handoff folder.

## PCB settings

- Layers: 2
- Material: FR-4
- Board thickness: **1.0 mm**
- Surface finish: **ENIG**
- Copper weight: 1 oz
- Solder mask: green, unless a different color is desired
- Silkscreen: white
- Gold fingers: no
- Castellated holes: no (the RP2040-Zero itself has castellated pads; the carrier PCB does not)
- Confirm the detected outline is about 120.5 × 64.8 mm and has the irregular WonderSwan shell shape.
- Let JLCPCB add assembly tooling holes, fiducials, and process rails as required.

The 1.0 mm thickness and ENIG finish are requirements from the original project. ENIG also keeps the rubber-button contact surfaces flat and oxidation-resistant.

## Assembly choices

- Start with Economic PCBA if the site accepts every selected part; switch to Standard PCBA if the RP2040-Zero is flagged as Standard-only or requires manual review.
- Use the original listed parts:
  - R1–R6: C17414, 10 kΩ 0805
  - Q1–Q3: C112239, BSS138 SOT-23
  - U2: C5350143, Waveshare RP2040-Zero
- The RP2040-Zero is a bottom-side SMT module and may trigger a fixture/manual-review fee.
- If C5350143 is short on assembly stock, use JLCPCB's parts pre-order service for the required quantity, then place the PCBA order after the parts appear in My Parts Lib. Do not substitute a bare RP2040 IC.
- This CPL is for one single PCB. If the order page asks about panel placement data, select “Single piece, please help me repeat the data.”

## Mandatory DFM visual checks before paying

The project supplied only Gerbers, so these checks are the final safeguard:

1. Confirm all ten designators in the BOM are also present in the CPL: R1–R6, Q1–Q3, and U2.
2. Confirm R1/R4/R6 are horizontal and R2/R3/R5 are vertical.
3. Confirm Q1/Q2/Q3 all have the same orientation: their two-pin side faces the nearby R1/R4/R6 row, and their single-pin side faces R2/R3/R5.
4. Confirm U2 is on the **bottom** and its USB-C connector faces the large cutout/right edge of the PCB.
5. Confirm there is no paste on the 13 rubber-button contact pairs or the five SNES cable solder pads. The included assembly Gerbers intentionally correct those paste layers without changing copper, mask, drill, or outline data.
6. Compare the DFM preview with `top-render.png` and `bottom-render.png`.

Stop and correct the rotation in JLCPCB's placement viewer if any polarized part preview disagrees with these checks. Resistor polarity does not matter.

## What “assembled” does and does not include

The PCBA order should arrive with R1–R6, Q1–Q3, and U2 soldered. It will still need:

- The included `swantroller.uf2` firmware flashed to U2 over USB-C.
- A cut SNES controller extension cable soldered to the five bottom pads labeled 5V, CLK, LAT, DAT, and GND. Verify the cable conductors with a multimeter; cable colors are not standardized.
- Installation in an empty WonderSwan Color shell with the original buttons and conductive rubber membranes.

The assembly house will not normally flash this hobby-project firmware, attach the cable, or install the board in a shell unless separately quoted as custom work.

## RP2040 variant warning from the project author

This version can boot incorrectly if a powered-off swancolorHD is weakly back-fed through HDMI. The documented workaround is to connect the controller after the swancolorHD is already powered, or use a display setup that does not back-feed it.

## Provenance

- Source repository: https://github.com/zwenergy/swantroller
- Source commit in the supplied archive: `04914cd5bb6b08df978566673ae80e47587bcde4`
- Firmware release: https://github.com/zwenergy/swantroller/releases/tag/v1.0
- Firmware SHA-256: `5a235550f020995a201a6e7c44c87ddcf6a6ae4ad2f1ee936fab94a5d4d3c3c1`
- Package prepared: 2026-07-14
